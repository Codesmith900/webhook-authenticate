from flask import Flask, request, jsonify
from authenticate import WebhookAuthenticator, WebhookConfig, AuthMethod, FrameSamplingStrategy
import os

app = Flask(__name__)

# Initialize authenticator
auth = WebhookAuthenticator()

# Register Netlify webhook (you'll set the secret after ngrok)
github_config = WebhookConfig(
    secret=os.getenv('GITHUB_WEBHOOK_SECRET', 'temp-secret'),
    auth_method=AuthMethod.HMAC_SHA256,
    sampling_strategy=FrameSamplingStrategy.RISK_BASED
)
auth.register_webhook('github', github_config)

@app.route('/webhook/github', methods=['POST'])
def handle_github_webhook():
    headers = dict(request.headers)
    payload = request.get_data()
    
    result = auth.authenticate_webhook('github', headers, payload)
    
    if not result.is_valid:
        return {"error": result.error_message}, 401
    
    data = request.get_json()
    print(f"GitHub webhook received: {data}")
    
    return {"status": "success"}

if __name__ == '__main__':
    app.run(debug=True, port=5000)

# Add this debug line in your app.py
print(f"Using GitHub secret: {os.getenv('GITHUB_WEBHOOK_SECRET', 'temp-secret')}")